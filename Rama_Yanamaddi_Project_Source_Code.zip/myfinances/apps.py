from django.apps import AppConfig


class MyFinancesConfig(AppConfig):
    name = 'myfinances'
    default_auto_field = 'django.db.models.AutoField'
