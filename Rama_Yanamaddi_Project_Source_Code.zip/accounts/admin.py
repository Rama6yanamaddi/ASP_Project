from django.contrib import admin

# Register your models here.


 
from .models import LoginLog

admin.site.register(LoginLog)

