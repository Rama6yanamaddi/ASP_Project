from django.apps import AppConfig

# Config for accounts app
class AccountsConfig(AppConfig):
    name = 'accounts'
